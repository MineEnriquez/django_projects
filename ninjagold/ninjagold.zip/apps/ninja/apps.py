from django.apps import AppConfig


class NinjaConfig(AppConfig):
    name = 'ninja'
