from django.apps import AppConfig


class NinjitaConfig(AppConfig):
    name = 'ninjita'
