from django.apps import AppConfig


class GeneratewordConfig(AppConfig):
    name = 'generateword'
