from django.apps import AppConfig


class HowartsConfig(AppConfig):
    name = 'howarts'
