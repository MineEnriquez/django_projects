from django.apps import AppConfig


class SingleappConfig(AppConfig):
    name = 'singleapp'
